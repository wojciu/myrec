import { create } from 'zustand';
import { api } from '@/lib/api-client';
import { useAuthStore } from '@/store/auth';

interface DashboardStats {
  openTasksCount: number;
  openTasksCountMine: number;
  inProgressTasksCount: number;
  inProgressTasksCountMine: number;
  overdueTasksCount: number;
  overdueTasksCountMine: number;
  todayEntriesCount: number;
  unreadEntriesCount: number;
  unreadEntriesCountTotal: number;
  recentEntries: any[];
  urgentTasks: any[];
}

interface DashboardState {
  stats: DashboardStats | null;
  loading: boolean;
  error: string | null;
  fetchStats: () => Promise<void>;
}

export const useDashboardStore = create<DashboardState>((set, get) => ({
  stats: null,
  loading: false,
  error: null,

  fetchStats: async () => {
    set({ loading: true, error: null });
    try {
      const [entriesData, tasksData, dashboardStats] = await Promise.all([
        api.get<{ entries: any[] }>('/api/entries?limit=50'),
        api.get<{ tasks: any[] }>('/api/tasks?limit=50'),
        api.get<{
          openTasksCount: number;
          openTasksCountMine: number;
          inProgressTasksCount: number;
          inProgressTasksCountMine: number;
          overdueTasksCount: number;
          overdueTasksCountMine: number;
          unreadEntriesCountTotal: number;
          todayEntriesCount: number;
        }>('/api/dashboard/stats'),
      ]);

      const tasks = tasksData.tasks || [];
      const entries = entriesData.entries || [];
      const user = useAuthStore.getState().user;

      const now = new Date();

      // Unread entries for current user
      const unreadEntriesCount = entries.filter((e: any) => {
        if (!user) return true;
        return !e.readBy?.some((r: any) => r.userId === user.id);
      }).length;

      const urgentTasks = tasks
        .filter((t: any) =>
          (t.status === 'open' || t.status === 'in_progress') &&
          (t.priority === 1 || (t.dueAt && new Date(t.dueAt) < new Date(now.getTime() + 24 * 60 * 60 * 1000)))
        )
        .slice(0, 10);

      const recentEntries = entries.slice(0, 5);

      set({
        stats: {
          openTasksCount: dashboardStats.openTasksCount,
          openTasksCountMine: dashboardStats.openTasksCountMine,
          inProgressTasksCount: dashboardStats.inProgressTasksCount,
          inProgressTasksCountMine: dashboardStats.inProgressTasksCountMine,
          overdueTasksCount: dashboardStats.overdueTasksCount,
          overdueTasksCountMine: dashboardStats.overdueTasksCountMine,
          todayEntriesCount: dashboardStats.todayEntriesCount,
          unreadEntriesCount,
          unreadEntriesCountTotal: dashboardStats.unreadEntriesCountTotal,
          recentEntries,
          urgentTasks,
        },
        loading: false,
      });
    } catch (error) {
      set({ error: (error as Error).message, loading: false });
    }
  },
}));
