(()=>{var E={};E.id=288,E.ids=[288],E.modules={5486:E=>{"use strict";E.exports=require("bcrypt")},846:E=>{"use strict";E.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},4870:E=>{"use strict";E.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:E=>{"use strict";E.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},9294:E=>{"use strict";E.exports=require("next/dist/server/app-render/work-async-storage.external.js")},3033:E=>{"use strict";E.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},9021:E=>{"use strict";E.exports=require("fs")},3873:E=>{"use strict";E.exports=require("path")},9070:(E,e,T)=>{"use strict";T.r(e),T.d(e,{patchFetch:()=>U,routeModule:()=>I,serverHooks:()=>c,workAsyncStorage:()=>A,workUnitAsyncStorage:()=>o});var t={};T.r(t),T.d(t,{GET:()=>R});var r=T(2706),a=T(8203),N=T(5994),s=T(9187),i=T(4272),d=T(3873),n=T.n(d),L=T(9021);async function R(){try{let E=n().join(process.cwd(),"prisma","prod.db");if(!(0,L.existsSync)(E)){let e=n().dirname(E);(0,L.existsSync)(e)||(0,L.mkdirSync)(e,{recursive:!0}),await i.z.$connect(),await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "User" (
          "id" TEXT PRIMARY KEY,
          "email" TEXT NOT NULL UNIQUE,
          "passwordHash" TEXT NOT NULL,
          "displayName" TEXT NOT NULL,
          "role" TEXT NOT NULL DEFAULT 'receptionist',
          "departmentId" TEXT,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("departmentId") REFERENCES "Department"("id") ON DELETE SET NULL
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "Department" (
          "id" TEXT PRIMARY KEY,
          "name" TEXT NOT NULL,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "EntryCategory" (
          "id" TEXT PRIMARY KEY,
          "name" TEXT NOT NULL UNIQUE,
          "color" TEXT NOT NULL DEFAULT 'bg-gray-100 text-gray-800',
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "Entry" (
          "id" TEXT PRIMARY KEY,
          "authorId" TEXT NOT NULL,
          "title" TEXT,
          "body" TEXT NOT NULL,
          "categoryId" TEXT NOT NULL,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("authorId") REFERENCES "User"("id"),
          FOREIGN KEY ("categoryId") REFERENCES "EntryCategory"("id")
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "_EntryToDepartment" (
          "A" TEXT NOT NULL,
          "B" TEXT NOT NULL,
          FOREIGN KEY ("A") REFERENCES "Entry"("id") ON DELETE CASCADE,
          FOREIGN KEY ("B") REFERENCES "Department"("id") ON DELETE CASCADE
        )
      `,await i.z.$executeRaw`
        CREATE UNIQUE INDEX IF NOT EXISTS "_EntryToDepartment_AB_unique" ON "_EntryToDepartment"("A", "B")
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "EntryReadBy" (
          "id" TEXT PRIMARY KEY,
          "entryId" TEXT NOT NULL,
          "userId" TEXT NOT NULL,
          "readAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("entryId") REFERENCES "Entry"("id") ON DELETE CASCADE,
          FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
          UNIQUE ("entryId", "userId")
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "Task" (
          "id" TEXT PRIMARY KEY,
          "title" TEXT NOT NULL,
          "description" TEXT,
          "status" TEXT NOT NULL DEFAULT 'open',
          "priority" INTEGER NOT NULL DEFAULT 2,
          "createdById" TEXT,
          "assigneeId" TEXT,
          "assigneeDepartmentId" TEXT,
          "entryId" TEXT,
          "dueAt" DATETIME,
          "reminderAt" DATETIME,
          "reminderSentAt" DATETIME,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE SET NULL,
          FOREIGN KEY ("assigneeId") REFERENCES "User"("id") ON DELETE SET NULL,
          FOREIGN KEY ("assigneeDepartmentId") REFERENCES "Department"("id") ON DELETE SET NULL,
          FOREIGN KEY ("entryId") REFERENCES "Entry"("id") ON DELETE SET NULL
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "TaskComment" (
          "id" TEXT PRIMARY KEY,
          "taskId" TEXT NOT NULL,
          "userId" TEXT NOT NULL,
          "content" TEXT NOT NULL,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("taskId") REFERENCES "Task"("id") ON DELETE CASCADE,
          FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "Attachment" (
          "id" TEXT PRIMARY KEY,
          "entryId" TEXT,
          "taskId" TEXT,
          "filePath" TEXT NOT NULL,
          "fileName" TEXT NOT NULL,
          "contentType" TEXT NOT NULL,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("entryId") REFERENCES "Entry"("id") ON DELETE SET NULL,
          FOREIGN KEY ("taskId") REFERENCES "Task"("id") ON DELETE SET NULL
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "Notification" (
          "id" TEXT PRIMARY KEY,
          "userId" TEXT NOT NULL,
          "type" TEXT NOT NULL,
          "title" TEXT NOT NULL,
          "message" TEXT NOT NULL,
          "taskId" TEXT,
          "entryId" TEXT,
          "read" INTEGER NOT NULL DEFAULT 0,
          "readAt" DATETIME,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
          FOREIGN KEY ("taskId") REFERENCES "Task"("id") ON DELETE SET NULL,
          FOREIGN KEY ("entryId") REFERENCES "Entry"("id") ON DELETE SET NULL
        )
      `,await i.z.$executeRaw`
        CREATE TABLE IF NOT EXISTS "TaskActivity" (
          "id" TEXT PRIMARY KEY,
          "taskId" TEXT NOT NULL,
          "userId" TEXT NOT NULL,
          "type" TEXT NOT NULL,
          "details" TEXT,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY ("taskId") REFERENCES "Task"("id") ON DELETE CASCADE,
          FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
        )
      `,await i.z.department.create({data:{id:"dept-reception",name:"Recepcja"}}),await i.z.entryCategory.createMany({data:[{id:"cat-info",name:"Informacja",color:"bg-blue-100 text-blue-800"},{id:"cat-warning",name:"Ostrzeżenie",color:"bg-yellow-100 text-yellow-800"},{id:"cat-incident",name:"Incident",color:"bg-red-100 text-red-800"},{id:"cat-request",name:"Prośba",color:"bg-purple-100 text-purple-800"}]});let t=T(5486),r=await t.hash("password123",10);return await i.z.user.create({data:{id:"test-user-1",email:"test@hotel.com",passwordHash:r,displayName:"Test User",role:"admin",departmentId:"dept-reception"}}),await i.z.$disconnect(),s.NextResponse.json({success:!0,message:"Baza danych utworzona",initialized:!0})}return s.NextResponse.json({success:!0,message:"Baza danych już istnieje",initialized:!1})}catch(E){return console.error("Init error:",E),s.NextResponse.json({success:!1,error:E instanceof Error?E.message:"Unknown error"},{status:500})}}let I=new r.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/init/route",pathname:"/api/init",filename:"route",bundlePath:"app/api/init/route"},resolvedPagePath:"/Users/wojteks/Development/next.js example/myrec/src/app/api/init/route.ts",nextConfigOutput:"standalone",userland:t}),{workAsyncStorage:A,workUnitAsyncStorage:o,serverHooks:c}=I;function U(){return(0,N.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:o})}},6487:()=>{},8335:()=>{},4272:(E,e,T)=>{"use strict";T.d(e,{z:()=>N});let t=require("@prisma/client");var r=T(3873),a=T.n(r);let N=globalThis.prisma??new t.PrismaClient({log:["error"],datasources:{db:{url:(()=>{let E=process.env.DATABASE_URL;if(E?.startsWith("file:")){let e=E.replace("file:",""),T=a().join(process.cwd(),e);return`file:${T}`}return E})()}}})}};var e=require("../../../webpack-runtime.js");e.C(E);var T=E=>e(e.s=E),t=e.X(0,[638,71],()=>T(9070));module.exports=t})();